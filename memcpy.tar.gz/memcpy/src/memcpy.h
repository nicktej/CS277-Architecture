void *memcpy2(void *dest, const void *src, size_t n);
